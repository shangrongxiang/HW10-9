package unbrella;
//In rainy days, if there is strong wind, the umbrella 
//will be fixed on top of our head and will not be damaged.
//The umbrella has an automatic drying function, 
//and the umbrella size can also be automatically adjusted
public class Rainumbrella extends unbrella{
	public static void Stable_umbrella() {
		System.out.println("Stable Umbrella open");
	}
	public void Adjuge_size(){
		System.out.println("The size automaticly changes to bige size");
		
	}
	public void drying() {
		System.out.println("Drying Turn on");
		
	}
	public void Windproof() {
		System.out.println("Windproof trun on");
		
	}
}
